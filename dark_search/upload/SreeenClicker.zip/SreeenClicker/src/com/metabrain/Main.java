package com.metabrain;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.charset.Charset;
import java.util.*;

public class Main {

    static Point searchSubImage(BufferedImage imageA, BufferedImage imageB) {
        for (int i = 0; i <= imageA.getWidth() - imageB.getWidth(); i++) {
            for (int j = 0; j <= imageA.getHeight() - imageB.getHeight(); j++) {
                boolean success = true;

                for (int k = 0; k < imageB.getWidth(); k++) {
                    for (int l = 0; l < imageB.getHeight(); l++) {
                        if (imageA.getRGB(i + k, j + l) != imageB.getRGB(k, l)) {
                            success = false;
                            break;
                        }
                    }
                    if (!success) break;
                }
                if (success)
                    return new Point(i, j);
            }
        }
        return null;
    }

    static void click(Point point) throws AWTException, InterruptedException {
        Thread.sleep(new Random().nextInt() % 200 + 200);
        Robot bot = new Robot();
        bot.mouseMove(point.x, point.y);
        bot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
    }

    static void move(Point point) throws AWTException, InterruptedException {
        Robot bot = new Robot();
        bot.mouseMove(point.x, point.y);
        Thread.sleep(100);
    }

    static void paste(String text) throws AWTException {
        StringSelection stringSelection = new StringSelection(text);
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(stringSelection, stringSelection);

        Robot robot = new Robot();
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_CONTROL);
    }

    static void scroll(int x) throws AWTException, InterruptedException {
        Thread.sleep(300);
        new Robot().mouseWheel(x);
    }

    static void clickGetter() throws InterruptedException {
        Point last = MouseInfo.getPointerInfo().getLocation();
        while (true) {
            Point point = MouseInfo.getPointerInfo().getLocation();
            Thread.sleep(1000);
            Point point2 = MouseInfo.getPointerInfo().getLocation();
            if (point.equals(point2) && !point2.equals(last)) {
                System.out.println("new Point(" + point.x + ", " + point.y + ");");
                last = point2;
            }
        }
    }

    static void press(int key) throws AWTException {
        new Robot().keyPress(key);
    }

    static void pressDouble(int firstKey, int secondKey) throws AWTException, InterruptedException {
        Robot robot = new Robot();
        robot.keyPress(firstKey);
        Thread.sleep(10);
        robot.keyPress(secondKey);
        Thread.sleep(100);
        robot.keyRelease(secondKey);
        Thread.sleep(10);
        robot.keyRelease(firstKey);
        Thread.sleep(300);
    }

    static BufferedImage screenshot() throws AWTException {
        return new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
    }

    static Map<String, Integer> clickedSum = new LinkedHashMap<>();

    static void findAndClick() throws Exception {
        Set<String> clicked = new HashSet<>();
        int i;
        for (i = 0; i < 3; i++) {
            Thread.sleep(600);
            BufferedImage screen = screenshot();
            for (String file : fileList()) {
                Point point = searchSubImage(screen, ImageIO.read(new File("find/" + file)));
                if (point != null) {
                    Integer count = clickedSum.get(file);
                    count = count == null ? 1 : count;
                    System.out.println(file + " " + count);
                    click(new Point(point.x + 30, point.y + 30));
                    Thread.sleep(5000);
                    pressDouble(KeyEvent.VK_ALT, KeyEvent.VK_LEFT);
                }
            }
            scroll(300);
        }
    }

    static ArrayList<String> fileList() {
        ArrayList<String> result = new ArrayList<>();
        for (File file : new File("find").listFiles()) {
            String filename = file.getName();
            if (!filename.equals(".") && !filename.equals(".."))
                result.add(filename);
        }
        return result;
    }

    static void googleClick() throws Exception {
        pressDouble(KeyEvent.VK_ALT, KeyEvent.VK_TAB);
        pressDouble(KeyEvent.VK_CONTROL, KeyEvent.VK_T);
        paste(new String(Base64.getDecoder().decode("0LTQtdC90YzQs9C4INCyINC00L7Qu9CzINC80LjQvdGB0Lo="), Charset.forName("UTF-8")));
        press(KeyEvent.VK_ENTER);
        Thread.sleep(2000);
        move(new Point(300, 300));
        findAndClick();
        /*click(new Point(1478, 54));
        click(new Point(1362, 330));*/
        pressDouble(KeyEvent.VK_CONTROL, KeyEvent.VK_W);
        pressDouble(KeyEvent.VK_ALT, KeyEvent.VK_TAB);
        Thread.sleep(2000);
    }

    public static void main(String[] args) throws Exception {
        // clickGetter();
        while (true)
            googleClick();
    }
}
